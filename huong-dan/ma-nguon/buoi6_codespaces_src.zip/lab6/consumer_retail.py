"""Consumer Python thuộc một consumer group (Buổi 6 - CT428).

Mỗi tiến trình là một thành viên của group; in ra partition được gán sau mỗi lần rebalance
và đếm số bản ghi nhận được theo partition.
"""
import argparse
import json
import socket
from collections import Counter

from kafka import KafkaConsumer, ConsumerRebalanceListener

parser = argparse.ArgumentParser()
parser.add_argument("--bootstrap", default="kafka:9092")
parser.add_argument("--topic", default="retail-transactions")
parser.add_argument("--group", default="retail-py-group")
parser.add_argument("--name", default=socket.gethostname())
parser.add_argument("--idle", type=int, default=0,
                    help="tự dừng sau N giây không có bản ghi mới (0 = chạy mãi, Ctrl+C để dừng)")
args = parser.parse_args()


class InBaoRebalance(ConsumerRebalanceListener):
    def on_partitions_revoked(self, revoked):
        print(f"[{args.name}] bi thu hoi partition: {sorted(tp.partition for tp in revoked)}", flush=True)

    def on_partitions_assigned(self, assigned):
        print(f"[{args.name}] duoc gan partition: {sorted(tp.partition for tp in assigned)}", flush=True)


consumer = KafkaConsumer(
    bootstrap_servers=args.bootstrap,
    group_id=args.group,
    auto_offset_reset="earliest",
    enable_auto_commit=True,
    value_deserializer=lambda b: json.loads(b.decode("utf-8")),
    consumer_timeout_ms=args.idle * 1000 if args.idle > 0 else float("inf"),
)
consumer.subscribe([args.topic], listener=InBaoRebalance())

counts = Counter()
try:
    for msg in consumer:
        counts[msg.partition] += 1
        total = sum(counts.values())
        if total % 200 == 0:
            print(f"[{args.name}] da nhan {total} ban ghi, theo partition: {dict(sorted(counts.items()))}", flush=True)
except KeyboardInterrupt:
    pass
finally:
    consumer.close()
    print(f"[{args.name}] TONG: {sum(counts.values())} ban ghi, theo partition: {dict(sorted(counts.items()))}", flush=True)

"""Structured Streaming: Kafka -> cửa sổ 5 phút + watermark 2 phút -> console (Buổi 6 - CT428)."""
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr, from_json, sum as _sum, count as _count, window

spark = SparkSession.builder.appName("RetailStreamingConsole").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

schema = ("transaction_id STRING, customer_id STRING, product_id STRING, "
          "category STRING, quantity INT, unit_price DOUBLE, discount DOUBLE, "
          "store_id STRING, region STRING, ts STRING")

raw = (spark.readStream.format("kafka")
       .option("kafka.bootstrap.servers", "kafka:9092")
       .option("subscribe", "retail-transactions")
       .option("startingOffsets", "latest")
       .load())

parsed = (raw.selectExpr("CAST(value AS STRING) AS json_str")
          .select(from_json(col("json_str"), schema).alias("d"))
          .select("d.*")
          .withColumn("event_time", col("ts").cast("timestamp"))
          .withColumn("revenue", expr("quantity * unit_price * (1 - discount)")))

agg = (parsed
       .withWatermark("event_time", "2 minutes")
       .groupBy(window(col("event_time"), "5 minutes"), col("category"))
       .agg(_count("*").alias("n_txn"),
            _sum("revenue").alias("total_revenue"),
            _sum("quantity").alias("total_qty")))

query = (agg.writeStream
         .outputMode("update")
         .format("console")
         .option("truncate", "false")
         .option("numRows", 20)
         .trigger(processingTime="10 seconds")
         .start())

query.awaitTermination()
